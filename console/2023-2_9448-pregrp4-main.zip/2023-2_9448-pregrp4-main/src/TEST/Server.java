package TEST;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;

public class Server implements ActionListener {

    private ServerSocket serverSocket;
    private Transaction transactions;
    private SynchList outputs;
    private int port_number = 5000;
    private static ArrayList<String> online_users;
    private JFrame window;
    private JPanel cover;
    private JButton run,stop;
    private Color color1 = new Color(0, 255, 255);

    public Server() {

        runPanel();
    }
    public void runPanel() {

        window = new JFrame("Server Config");

        cover = new JPanel();
        cover.setLayout(null);
        cover.setBackground(new java.awt.Color(0, 0, 50));

        run = new JButton("Start Server");
        run.setBounds(200, 50, 100, 30);
        run.setBackground(color1);
        run.addActionListener(this);

        stop = new JButton("Stop Server");
        stop.setBounds(200, 100, 100, 30);
        stop.setBackground(color1);
        stop.addActionListener(this);

        cover.add(run);
        cover.add(stop);
        window.add(cover);

        window.setResizable(false);
        window.setSize(500, 250);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);

    }
    public void runServer() {
        try {
            System.out.println("Starting port: "+port_number);

            if (port_number > 0) {
                serverSocket = new ServerSocket(port_number);
                outputs = new SynchList();
                online_users = new ArrayList<String>();
                online_users.add("Everyone");
            }

            while (true) {
                transactions = new Transaction(outputs.size(), outputs,online_users ,serverSocket.accept());
                System.out.println("Server is now listening on port "+port_number +".....");
                transactions.start();
                System.out.println("Client has joined...");
            }
        } catch (Exception i) {
            System.out.println("Transaction failed: " + i);
        }
    }

    public void stopServer() {
        try {
            serverSocket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        new Server();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == run) {
            JOptionPane.showMessageDialog(null, "Server is now listening on port: " + port_number);
            runServer();

            window.setState(Frame.ICONIFIED);
        }
            if (e.getSource() == stop);
                JOptionPane.showMessageDialog(null, "Server is now stopping: " + port_number);
            stopServer();
        }
    }



