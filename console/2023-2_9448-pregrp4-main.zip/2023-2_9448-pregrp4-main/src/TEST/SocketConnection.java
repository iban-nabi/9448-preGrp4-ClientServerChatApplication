package TEST;
public interface SocketConnection {
    void communicate();
}
