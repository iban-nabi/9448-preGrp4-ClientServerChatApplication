package TEST;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
public class Client1GUI implements SocketConnection, ActionListener, ItemListener {
    private Socket socket;
    private ObjectInputStream inputStream;
    private ObjectOutputStream outputStream;
    private String CurrentToWho = "Everyone";
    private static ArrayList<String> users_lists;
    private JComboBox<String> display_users;
    private JPanel switchPanels;
    private JFrame frame;
    private JPanel cover;
    private JPanel main;
    private JTextField host;
    private JTextField clientName;
    private JButton run;
    private Color color1 = new Color(0, 255, 255);
    private JLabel labels_cover[];
    private JTextArea server;
    private JTextField input;
    private JScrollPane scrollBar;

    public void runPanel() {

        frame = new JFrame("Client");
        labels_cover = new JLabel[2];
        switchPanels = new JPanel(new CardLayout());

        cover = new JPanel(new GridLayout(2, 2));
        cover.setLayout(null);
        frame.setResizable(false);
        cover.setSize(700, 445);
        cover.setBackground(new java.awt.Color(0, 0, 50));

        clientName = new JTextField();
        clientName.setBounds(140, 60, 400, 40);
        clientName.addActionListener(this);
        labels_cover[0] = new JLabel("Username");
        labels_cover[0].setBounds(140, 30, 300, 40);
        labels_cover[0].setForeground(color1);
        cover.add(clientName);
        cover.add(labels_cover[0]);

        host = new JTextField();
        host.setBounds(140, 120, 400, 40);
        host.setText("localhost");
        host.addActionListener(this);
        labels_cover[1] = new JLabel("Host address");
        labels_cover[1].setBounds(140, 90, 300, 40);
        labels_cover[1].setForeground(color1);
        cover.add(labels_cover[1]);
        cover.add(host);

        run = new JButton("Run Client");
        run.setBounds(290, 180, 100, 50);
        run.setBackground(color1);
        run.addActionListener(this);
        cover.add(run);

        switchPanels.add(cover, "cover");

        main = new JPanel(new GridLayout(2, 2));
        frame.setResizable(false);
        main.setLayout(null);
        main.setSize(700, 445);
        main.setBackground(new java.awt.Color(0, 0, 50));

        mainInterface();
        frame.setSize(700, 445);

        switchPanels.add(main, "main");
        frame.add(switchPanels);

        frame.setSize(700, 445);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    public void mainInterface() {

        frame.setTitle(this.clientName.getText());

        Border thinBorder = LineBorder.createBlackLineBorder();
        server = new JTextArea();
        server.setEditable(false);
        server.setBorder(thinBorder);
        scrollBar = new JScrollPane(server);
        scrollBar.setBounds(140, 30, 500, 280);

        main.add(scrollBar);

        users_lists = new ArrayList<>();
        users_lists.add("Everyone");

        display_users = new JComboBox(users_lists.toArray());
        display_users.setBounds(20, 10, 100, 40);

        display_users.addItemListener(this);
        main.add(display_users);

        input = new JTextField();
        input.setBounds(140, 330, 500, 40);
        input.addActionListener(this);
        main.add(input);
    }
    class serverReader extends Thread {

        public void run() {
            try {
                MessageH p;
                String message = "";
                while ((p = (MessageH) inputStream.readObject()) != null) {

                    if(p.getToWho().equals("Everyone")) {
                        message = message + p.toString() + "\n";
                        server.setText(message);
                    }
                    if(p.getToWho().equals("Update")) {
                        updateOnlineUsers(p.getOnlineUsers());
                        message = message + p.toString() + "\n";
                        server.setText(message);
                    }
                    if(p.getToWho().toLowerCase().equals(clientName.getText().toLowerCase())) {
                        message = message + p.toString() + "\n";
                        server.setText(message);
                    }
                }
            } catch (Exception e) {
            }
        }
    }
    public Client1GUI() {
        try {
            runPanel();

            int port_number = 5000;
            socket = new Socket(host.getText(), port_number);
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            inputStream = new ObjectInputStream(socket.getInputStream());

            new serverReader().start();

        } catch (UnknownHostException u) {
            System.out.println(u);
        } catch (IOException i) {
            System.out.println(i);
        }
    }
    public void communicate() {
        try {
            String message = input.getText();
            outputStream.writeObject(new MessageH(this.clientName.getText(), message, CurrentToWho));
            outputStream.flush();
        } catch (IOException i) {
            System.out.println("Error " + i);
        }
        input.setText("");
    }
    public void joinUser() {
        try {
            outputStream.writeObject(new MessageH("@join", clientName.getText(), "Update"));
            outputStream.flush();
        } catch (IOException i) {
            System.out.println("Error " + i);
        }
        input.setText("");
    }
    public void updateOnlineUsers(ArrayList<String> updated_users){
        Set<String> set = new HashSet<>(updated_users);
        users_lists.clear();
        users_lists.addAll(set);

        System.out.print(users_lists);
        DefaultComboBoxModel defaultComboBoxModel = new DefaultComboBoxModel(users_lists.toArray());
        display_users.setModel(defaultComboBoxModel);
    }
    public void closeConnections() {
        try {
            inputStream.close();
            outputStream.close();
            this.socket.close();
        } catch (IOException i) {
            System.out.println(i);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        CardLayout changePages = (CardLayout) (switchPanels.getLayout());
        if (e.getSource() == run && clientName.getText().length() < 1) {
            JOptionPane.showMessageDialog(null, "All forms must be filled!");
        }
        if (e.getSource() == run && clientName.getText().length() > 0) {
            changePages.show(switchPanels, "main");
            frame.setSize(700, 445);
            joinUser();
        }
        if (!input.getText().equals("")) {
            communicate();
        }
    }
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            CurrentToWho = (String) e.getItem();
        }
    }
    public static void main(String[] args) {
        new Client1GUI();
    }
}