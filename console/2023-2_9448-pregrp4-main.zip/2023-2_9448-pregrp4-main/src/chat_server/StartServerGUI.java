package chat_server;

import GUI.ServerGUI.ServerGUI;

/**
 * Start the server for Chat Service
 */
public class StartServerGUI {
    public static void main(String[] args) {
        new ServerGUI();

    }
}
