package GUI.ServerGUI;

import chat_server.tools.MoveListener;

import java.awt.*;
import javax.swing.*;

public class ADMINGUI extends JFrame {
    public static void main(String[] args) {
        new ADMINGUI();
    }
    public ADMINGUI() {
        setUndecorated(true);
        getRootPane().setWindowDecorationStyle(JRootPane.NONE);
        this.b1 = new JButton("Manage Server");
        this.b2 = new JButton("Manage User");
        this.b3 = new JButton("Back");

        this.p1 = new JPanel(new GridLayout(2, 2));
        p1.setBackground(new java.awt.Color(0, 0, 50));
        this.p2 = new JPanel(new GridLayout(1, 1));
        p2.setBackground(new java.awt.Color(0, 0, 50));
        this.p3 = new JPanel(new FlowLayout());
        p3.setBackground(new java.awt.Color(0, 0, 50));

        MoveListener listener = new MoveListener(this);
        p1.addMouseListener(listener);
        p1.addMouseMotionListener(listener);

        this.p1.add(this.b1);
        b1.setBounds(200, 200, 300, 30);
        b1.setBackground(new java.awt.Color(0, 255, 255));
        b1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.p1.add(this.b2);
        b2.setBounds(200, 240, 300, 30);
        b2.setBackground(new java.awt.Color(0, 255, 255));
        b2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.p1.add(this.b3);
        b3.setBounds(200, 280, 300, 30);
        b3.setBackground(new java.awt.Color(0, 255, 255));
        b3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.add(p1, BorderLayout.NORTH);
        p1.setMaximumSize(new java.awt.Dimension(700, 445));
        p1.setMinimumSize(new java.awt.Dimension(700, 445));
        p1.setPreferredSize(new java.awt.Dimension(700, 445));
        p1.setLayout(null);

        this.setTitle("Messenger (Server)");
        this.setMinimumSize(700, 445);
        this.setMaximumSize(700, 445);
        setPreferredSize(700, 445);
        setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        b1.setText("Manage Server");
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1Performed(evt);
            }
        });
        b2.setText("Manage User");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2Performed(evt);
            }
        });
        b3.setText("Back");
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3Performed(evt);
            }
        });
    }
    private void b1Performed(java.awt.event.ActionEvent evt) {new ServerGUI();}
    private void b2Performed(java.awt.event.ActionEvent evt){
        new ManageUserGUI();
    }
    private void b3Performed(java.awt.event.ActionEvent evt) {
//        new MenuGUI();
    }

    private void setMinimumSize(int i, int i1) {
    }
    private void setMaximumSize(int i, int i1) {
    }
    private void setPreferredSize(int i, int i1) {
    }
    public JPanel p1, p2, p3;
    public JButton b1, b2, b3;
    }



