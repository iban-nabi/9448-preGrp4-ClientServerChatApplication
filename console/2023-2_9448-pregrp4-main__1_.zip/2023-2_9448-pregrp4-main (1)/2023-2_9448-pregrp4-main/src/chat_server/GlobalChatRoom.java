package chat_server;

import java.io.*;
import java.net.Socket;

public class GlobalChatRoom {
    private final Socket socket;
    private final String sendTo = "Global";
    private final String name;

    public GlobalChatRoom(Socket socket, String name) throws IOException {
        this.socket = socket;
        this.name = name;
    }

    public void runGlobalChat() throws IOException {
        try{
            while(true){
                MessagingHandler chatRoom = new MessagingHandler(socket,name,sendTo);
                chatRoom.run();

                if(MessagingHandler.getListOfUsers().stream().noneMatch(o -> o.getName().equals(name))){
                    break;
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
