package chat_server;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class GroupChatService {
    private String admin;
    private String grpName;
    private Socket socket;
    private String name;
    private final List<String> listOfMembers = new ArrayList<>();

    public GroupChatService(Socket socket){
        this.socket=socket;
    }

    public void addMember(String member){
        listOfMembers.add(member);
    }

    public void setGrpName(String grpName) {
        this.grpName = grpName;
    }

    public void setAdmin(String admin){
        this.admin=admin;
    }

    public void setName(String name){
        this.name=name;
    }

    public List<String> getListOfMembers(){
        return listOfMembers;
    }

    public String getGrpName() {
        return grpName;
    }

    public void runGroupChat(){
        try{
            while(true){
                MessagingHandler chatHandler = new MessagingHandler(socket,name,grpName);
                chatHandler.run();

                if(MessagingHandler.getListOfUsers().stream().noneMatch(o -> o.getName().equals(name))){
                    break;
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
