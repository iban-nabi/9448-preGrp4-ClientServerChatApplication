package chat_server;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ChatServerHandler extends Thread{

    private String name;
    private final BufferedReader streamRdr;
    private final BufferedWriter streamWtr;
    private final Socket socket;
    private static final List<ChatServerHandler> onlineUsers = new ArrayList<>();
    private final List<GroupChatService> listOfGroupChats = new ArrayList<>();
    private final List<GroupChatService>userGroupChats = new ArrayList<>();


    public ChatServerHandler(Socket socket) throws IOException {
        this.socket=socket;
        streamRdr = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        streamWtr = new BufferedWriter(new PrintWriter(socket.getOutputStream(),true));
    }


    @Override
    public void run() {
        try{
            boolean loginSuccess = false;
            processGroupChat();
            while(!loginSuccess){
                loginSuccess=login();
            }

            while(true){
                streamWtr.write("Select option");
                streamWtr.newLine();
                streamWtr.write("1. Global Chat");
                streamWtr.newLine();
                streamWtr.write("2. Group Chat");
                streamWtr.newLine();
                streamWtr.write("3. Private Chat");
                streamWtr.newLine();
                streamWtr.write("Choose:");
                streamWtr.flush();
                int choice = Integer.parseInt(streamRdr.readLine());
                switch(choice){
                    case 1:
                        GlobalChatRoom globalChatRoom = new GlobalChatRoom(socket,name);
                        globalChatRoom.runGlobalChat();
                        break;

                    case 2: // group chats
                        for(GroupChatService groupChat: userGroupChats){
                            streamWtr.write(groupChat.getGrpName());
                            streamWtr.newLine();
                            streamWtr.flush();
                        }
                        streamWtr.write("Choose:");
                        streamWtr.flush();
                        int selectedGroupChat = Integer.parseInt(streamRdr.readLine());

                        userGroupChats.get(selectedGroupChat).setName(name);
                        streamWtr.newLine();
                        streamWtr.write(userGroupChats.get(selectedGroupChat).getGrpName());
                        streamWtr.newLine();
                        streamWtr.flush();
                        userGroupChats.get(selectedGroupChat).runGroupChat();
                        break;
                    case 3:
                        break;
                }
            }
        } catch (IOException | ParserConfigurationException | SAXException e) {
            e.printStackTrace();
        } finally {
            try {
                streamWtr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                streamRdr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public Document xmlReader(String fileName) throws ParserConfigurationException, IOException, SAXException {
        File xmlFile = new File(fileName);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        return builder.parse(xmlFile);
    }

    public boolean login() throws ParserConfigurationException, IOException, SAXException {
        streamWtr.write("Enter your username: ");
        streamWtr.flush();
        String inputUsername = streamRdr.readLine();

        streamWtr.write("Enter your password: ");
        streamWtr.flush();
        String inputPassword = streamRdr.readLine();

        String fileName = "res/Accounts.xml";
        Document doc = xmlReader(fileName);
        doc.getDocumentElement().normalize();

        NodeList accountXML = doc.getElementsByTagName("USER");
        for(int i = 0;i<accountXML.getLength();i++) {
            Node node = accountXML.item(i);
            Element e = (Element) node;
            String username = e.getElementsByTagName("NAME").item(0).getTextContent();
            String password = e.getElementsByTagName("PASSWORD").item(0).getTextContent();
            if(inputUsername.equalsIgnoreCase(username) && inputPassword.equals(password)){
                if(onlineUsers.stream().noneMatch(user -> user.name.equals(username))){
                    name=username;
                    processUserGroupChat();
                    onlineUsers.add(this);
                    return true;
                }else{
                    streamWtr.write("User is already login");
                    streamWtr.newLine();
                    streamWtr.flush();
                    return false;
                }
            }
        }
        streamWtr.write("Invalid Username or Password");
        streamWtr.newLine();
        streamWtr.flush();
        return false;
    }

    public void processGroupChat() throws ParserConfigurationException, IOException, SAXException {
        String fileName = "res/GroupChats.xml";
        Document doc = xmlReader(fileName);
        doc.getDocumentElement().normalize();

        NodeList grpChatXML = doc.getElementsByTagName("GRP");
        for(int i = 0;i<grpChatXML.getLength();i++) {
            GroupChatService groupChatService = new GroupChatService(socket);
            Node node = grpChatXML.item(i);
            Element e = (Element) node;
            groupChatService.setGrpName(e.getAttribute("name"));
            groupChatService.setAdmin(e.getElementsByTagName("ADMIN").item(0).getTextContent());
            groupChatService.addMember(e.getElementsByTagName("ADMIN").item(0).getTextContent()); // add the admin to the list of members

            NodeList members = e.getElementsByTagName("MEMBER");
            for(int j=0; j<members.getLength();j++){
                Node member = members.item(j);
                groupChatService.addMember(member.getTextContent());
            }
            System.out.println(groupChatService.getListOfMembers());
            listOfGroupChats.add(groupChatService);
        }
    }
    public void processUserGroupChat(){
        for(GroupChatService groupChat : listOfGroupChats){
            for(String member: groupChat.getListOfMembers()){
                if(name.equals(member)){
                    userGroupChats.add(groupChat);
                    break;
                }
            }
        }
    }
}
