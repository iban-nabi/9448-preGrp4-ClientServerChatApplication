package chat_server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ChatServer {
    public static void main(String[] args) throws IOException {

        ServerSocket serverSocket = null;
        try{
            serverSocket = new ServerSocket(3600);
            while(true){
                Socket socket = serverSocket.accept();
                ChatServerHandler chatServerHandler = new ChatServerHandler(socket);
                chatServerHandler.start();
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            if(serverSocket !=null){
                try{
                    serverSocket.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
    }
}
