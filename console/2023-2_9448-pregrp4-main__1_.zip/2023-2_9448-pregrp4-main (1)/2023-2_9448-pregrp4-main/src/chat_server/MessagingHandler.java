package chat_server;

import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class MessagingHandler implements Runnable{
    private String name;
    private String sendTo;
    private Socket socket;
    private BufferedReader streamRdr;
    private BufferedWriter streamWtr;
    private static List<MessagingHandler> listOfUsers = new CopyOnWriteArrayList<>();

    public MessagingHandler(Socket socket, String name, String sendTo) throws IOException {
        try{
            this.socket = socket;
            this.sendTo = sendTo;
            this.name = name;
            streamRdr = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            streamWtr = new BufferedWriter(new PrintWriter(socket.getOutputStream(),true));
            listOfUsers.add(this);
        }catch (Exception e){
            close();
        }
    }

    public String getName() {
        return name;
    }

    public static List<MessagingHandler> getListOfUsers() {
        return listOfUsers;
    }

    @Override
    public void run() {
        try {
            streamWtr.write(sendTo+" Server");
            streamWtr.newLine();
            streamWtr.flush();
            globalChat();
        } catch (IOException e) {
            close();
        }
    }

    public void globalChat() throws IOException {
        while(true){
            String textMsg = streamRdr.readLine();
            sendMessage(name+": "+textMsg);
            if(textMsg.equalsIgnoreCase("exit")){
                close();
                break;
            }
        }
    }

    public void sendMessage(String textMsg){
        try{
            for(MessagingHandler user: listOfUsers){
                if(!user.name.equals(name) && user.sendTo.equals(sendTo)){
                    user.streamWtr.write(textMsg);
                    user.streamWtr.newLine();
                    user.streamWtr.flush();
                }
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public void close() {
        listOfUsers.remove(this);
    }
}
