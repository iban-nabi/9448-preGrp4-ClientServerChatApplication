package GUI;

import java.awt.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.*;

public class ServerChatGUI extends JFrame {

    static ServerSocket serverSocket;
    static Socket socket;
    static DataInputStream input;
    static DataOutputStream output;

    public ServerChatGUI() {
        this.b1 = new JButton("Send");
        this.b2 = new JButton("Back");

        this.t1 = new JTextArea(1, 1);
        this.t2 = new JTextArea(35, 35);

        this.p1 = new JPanel(new GridLayout(2, 2));
        p1.setBackground(new java.awt.Color(0, 0, 50));
        this.p2 = new JPanel(new GridLayout(1, 1));
        p2.setBackground(new java.awt.Color(0, 0, 50));
        this.p3 = new JPanel(new FlowLayout());
        p3.setBackground(new java.awt.Color(0, 0, 50));

        this.p1.add(this.t1);
        t1.setBounds(220, 340, 390, 60);
        t1.setBackground(new java.awt.Color(200, 255, 255));
        t1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.p1.add(this.t2);
        t2.setBounds(100, 25, 510, 300);
        t2.setBackground(new java.awt.Color(200, 255, 255));
        t2.setEditable(false);
        t2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.p1.add(this.b1);
        b1.setBounds(100, 340, 100, 30);
        b1.setBackground(new java.awt.Color(0, 255, 255));
        b1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        this.p1.add(this.b2);
        b2.setBounds(100, 370, 100, 30);
        b2.setBackground(new java.awt.Color(0, 255, 255));
        b2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.add(p1, BorderLayout.NORTH);
        p1.setMaximumSize(new java.awt.Dimension(700, 445));
        p1.setMinimumSize(new java.awt.Dimension(700, 445));
        p1.setPreferredSize(new java.awt.Dimension(700, 445));
        p1.setLayout(null);

        this.setTitle("Messenger");
        this.setMinimumSize(700, 445);
        this.setMaximumSize(700, 445);
        setPreferredSize(700, 445);
        setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        b1.setText("Send");
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1Performed(evt);
            }
        });
        b2.setText("Back");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2Performed(evt);
            }
        });
    }

    private void b1Performed(java.awt.event.ActionEvent evt) {
        try {

            String msgout = "";
            msgout = t1.getText().trim();
            output.writeUTF(msgout);
        } catch (Exception e) {
        }
    }

    private void b2Performed(java.awt.event.ActionEvent evt) {
        new MenuGUI();
    }

    private void setMinimumSize(int i, int i1) {
    }

    private void setMaximumSize(int i, int i1) {
    }

    private void setPreferredSize(int i, int i1) {

    }

    public JPanel p1, p2, p3;
    public JTextArea t1;
    public static JTextArea t2;
    public JButton b1, b2;

    //STILL STATIC

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ServerChatGUI().setVisible(true);
            }
        });
        String msginp = "";
        try {
            serverSocket = new ServerSocket(3600);
            socket = serverSocket.accept();
            input = new DataInputStream(socket.getInputStream());
            output = new DataOutputStream(socket.getOutputStream());

            while (!msginp.equals("exit")) ;
            msginp = input.readUTF();
            t2.setText(t2.getText().trim() + "\n" +msginp);


        } catch (Exception e) {
        }

    }
}


