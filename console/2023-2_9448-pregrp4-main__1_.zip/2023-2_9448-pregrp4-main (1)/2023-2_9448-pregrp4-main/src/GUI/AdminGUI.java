package GUI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.*;

//ADMIN GUI TO BE FIXED
public class AdminGUI extends javax.swing.JFrame {
    public AdminGUI() {
        this.b1 = new JButton("Manage user");
        this.b2 = new JButton("Search for a user");

        this.p1 = new JPanel(new GridLayout(2, 2));
        p1.setBackground(new java.awt.Color(0, 0, 50));
        this.p2 = new JPanel(new GridLayout(1, 1));
        p2.setBackground(new java.awt.Color(0, 0, 50));
        this.p3 = new JPanel(new FlowLayout());
        p3.setBackground(new java.awt.Color(0, 0, 50));

        this.p1.add(this.b1);
        b1.setBounds(200, 250, 310, 30);
        b1.setBackground(new java.awt.Color(0, 255, 255));
        b1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        this.p1.add(this.b2);
        b2.setBounds(200, 280, 310, 30);
        b2.setBackground(new java.awt.Color(0, 255, 255));
        b2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.add(p1, BorderLayout.NORTH);
        p1.setMaximumSize(new java.awt.Dimension(700, 445));
        p1.setMinimumSize(new java.awt.Dimension(700, 445));
        p1.setPreferredSize(new java.awt.Dimension(700, 445));
        p1.setLayout(null);

        this.setTitle("Messenger Admin");
        this.setMinimumSize();
        this.setMaximumSize();
        setPreferredSize();
        setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        b1.setText("Manage User");
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1Performed(evt);}
        });
        b2.setText("Eme");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2Performed(evt);}
        });
    }
    private void b1Performed(java.awt.event.ActionEvent evt) {

        //Managing user (Add,Ban)
    }
    private void b2Performed(java.awt.event.ActionEvent evt) {

        //Link Sign Up GUI
    }

    private void setMinimumSize() {
    }
    private void setMaximumSize() {
    }
    private void setPreferredSize() {
    }

    public JPanel p1, p2, p3;
    public JButton b1, b2;

    public static void main(String args[]) {
        new AdminGUI();

    }

}


