package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MenuGUI extends JFrame {
    public JPanel p1;
    public JButton globalB, groupB, privateB;
    public JLabel userL;

    public MenuGUI() {
        //Frame
        this.setTitle("Menu");
        this.setSize(700, 445);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Panel
        this.p1 = new JPanel(new GridLayout(2, 2));
        p1.setBackground(new java.awt.Color(0, 0, 50));

        p1.setPreferredSize(new java.awt.Dimension(700, 445));
        p1.setLayout(null);
        this.add(p1, BorderLayout.NORTH);

        //Label
        this.userL = new JLabel("Hello, " + LoginGUI.getUser() + "!", SwingConstants.CENTER);
        userL.setBounds(300, 70, 80, 25);
        userL.setFont(new Font("SansSerif", Font.BOLD, 15));
        userL.setForeground(Color.white);
        this.p1.add(userL);

        //Button
        this.globalB = new JButton("Global Chat");
        globalB.setBounds(100, 120, 150, 150);
        globalB.setBackground(new java.awt.Color(0, 255, 255));
        globalB.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        globalB.addActionListener(this::b1Performed);
        this.p1.add(globalB);

        this.groupB = new JButton("Group Chat");
        groupB.setBounds(270, 120, 150, 150);
        groupB.setBackground(new java.awt.Color(0, 255, 255));
        groupB.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        groupB.addActionListener(this::b2Performed);
        this.p1.add(groupB);

        this.privateB = new JButton("Private Chat");
        privateB.setBounds(440, 120, 150, 150);
        privateB.setBackground(new java.awt.Color(0, 255, 255));
        privateB.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        privateB.addActionListener(this::b3Performed);
        this.p1.add(privateB);

        this.setVisible(true);
    }
        private void b1Performed(ActionEvent evt) {

        }
            private void b2Performed(ActionEvent evt) {

            }
               private void b3Performed(ActionEvent evt) {

        }

    public static void main(String[] args) {
        new MenuGUI(); // test run lang di kasi ako makapasok
    }
    }

