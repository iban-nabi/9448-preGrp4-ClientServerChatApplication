package GUI;

import chat_client.ChatClient;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;

public class LoginGUI extends JFrame{
    public NodeList nodes;
    public JPanel p1, p2, p3;
    public JTextArea nameTA, hostAddressTA;
    public JButton loginB;
    public JLabel usernameL, passwordL, hostAddressL;
    public JPasswordField passwordField;
    private static String user;

    public LoginGUI() {
        //Frame
        this.setTitle("Messenger");
        this.setSize(700, 445);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Panel
        this.p1 = new JPanel(new GridLayout(2, 2));
        p1.setBackground(new java.awt.Color(0, 0, 50));
        this.p2 = new JPanel(new GridLayout(1, 1));
        p2.setBackground(new java.awt.Color(0, 0, 50));
        this.p3 = new JPanel(new FlowLayout());
        p3.setBackground(new java.awt.Color(0, 0,50));

        p1.setPreferredSize(new java.awt.Dimension(700, 445));
        p1.setLayout(null);
        this.add(p1, BorderLayout.NORTH);

        //Button
        this.loginB = new JButton("Login");
        loginB.setBounds(200, 270, 310, 30);
        loginB.setBackground(new java.awt.Color(0, 255,255));
        loginB.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        loginB.addActionListener(this::b1Performed);
        this.p1.add(this.loginB);

        //Text Area and Labels
        this.nameTA = new JTextArea(1, 1);
        this.passwordField = new JPasswordField();
        this.hostAddressTA = new JTextArea();
        this.usernameL = new JLabel("Username");
        this.passwordL = new JLabel("Password");
        this.hostAddressL = new JLabel("Host Address");

        this.p1.add(this.usernameL);
        usernameL.setBounds(200, 70, 80,25);
        usernameL.setForeground (Color.white);

        this.p1.add(this.passwordL);
        passwordL.setBounds(200, 130, 80,25);
        passwordL.setForeground (Color.white);

        this.p1.add(this.hostAddressL);
        hostAddressL.setBounds(200, 190, 80,25);
        hostAddressL.setForeground (Color.white);

        this.p1.add(this.nameTA);
        nameTA.setBounds(200, 90, 310, 30);
        nameTA.setBackground(new java.awt.Color(200, 255,255));
        nameTA.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.p1.add(this.passwordField);
        passwordField.setBounds(200, 150, 310, 30);
        passwordField.setBackground(new java.awt.Color(200, 255,255));
        passwordField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        this.p1.add(this.hostAddressTA);
        hostAddressTA.setBounds(200, 210, 310, 30);
        hostAddressTA.setBackground(new java.awt.Color(200, 255,255));
        hostAddressTA.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));


        this.pack();
        this.setVisible(true);
    }

    private void b1Performed(ActionEvent evt) {
        boolean isFound = false;
        setUser(nameTA.getText());
        String pass = passwordField.getText();
        String ipAddress = hostAddressTA.getText();

        try{
            File inputFile = new File ("res\\Accounts.xml");
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(inputFile);

            document.getDocumentElement().normalize();
            nodes = document.getElementsByTagName("USER");
        }catch (Exception e){
            e.printStackTrace();
        }

        for(int i = 0; i < nodes.getLength(); i++){
            Node node = nodes.item(i);
            Element element = (Element) node;
            String name = element
                    .getElementsByTagName("NAME")
                    .item(0)
                    .getTextContent();
            String password = element
                    .getElementsByTagName("PASSWORD")
                    .item(0)
                    .getTextContent();
            if (getUser().equals(name) && pass.equals(password) &&
                    ChatClient.hostAddressChecker(ipAddress)) {
                ChatClient.Client(getUser(), pass, ipAddress);
                new MenuGUI();
                this.dispose();
                isFound = true;
            }
        }
        if(!isFound){
            JOptionPane.showMessageDialog(null, "Invalid Username/Password/Host Address",
                    "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
        //Lagay ung host address to connect to server
    }


    public static String getUser() {
        return user;
    }

    public static void setUser(String user) {
        LoginGUI.user = user;
    }
}
