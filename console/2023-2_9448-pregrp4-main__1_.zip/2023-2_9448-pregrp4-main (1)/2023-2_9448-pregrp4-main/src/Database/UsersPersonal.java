package Database;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;
import java.io.PrintWriter;

//XML FILE WRITER TO BE FIXED...

public class UsersPersonal {
    public static void main(String[] args) {
        Document document = createDocument();
        writeDOMToFile(document, "2023-2_9448-pregrp4-main/res/Users.xml");

    }
    private static Document createDocument () {
        Document document = null;
        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newDefaultInstance();
            DocumentBuilder documentBuilder = docBuilderFactory.newDocumentBuilder();
            document = documentBuilder.newDocument();

            Element root = document.createElement("Accounts");
            document.appendChild(root);

            Element client = document.createElement("USERS");
            assignUser(client, document, "Student","c");
            assignUser(client, document, "Cat","2");
            assignUser(client, document, "Student","3");
            root.appendChild(client);


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return document;
        }
    }

    private static void assignUser(Element department, Document doc, String name, String pass) {
        Element user= doc.createElement("user");
        Element empName = doc.createElement("name");
        Text txtData = doc.createTextNode(name);
        empName.appendChild(txtData);
        Element empPass = doc.createElement("pass");
        txtData = doc.createTextNode(pass);
        empPass.appendChild(txtData);

        user.appendChild(empName);
        user.appendChild(empPass);
        department.appendChild(user);

    }

    private static void writeDOMToFile (Node node, String fileName){
        try {
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(node);
            PrintWriter fileWriter = new PrintWriter(new FileOutputStream(fileName));
            StreamResult outputFile = new StreamResult(fileWriter);
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.transform(source, outputFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}