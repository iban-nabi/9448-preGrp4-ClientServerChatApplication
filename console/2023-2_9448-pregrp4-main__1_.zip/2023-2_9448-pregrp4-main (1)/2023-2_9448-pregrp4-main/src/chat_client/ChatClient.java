package chat_client;

import GUI.LoginGUI;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ChatClient {
    private static final int port = 3600;
//    private final static BufferedReader streamRdr;
//    private final static PrintWriter streamWtr;

    public static void main(String[] args) {
        new LoginGUI();
    }

    public static boolean hostAddressChecker(String ipAddress){
        try {
            new Socket(ipAddress, port);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void Client(String username, String password, String ipAddress){
        try (
                Socket socket = new Socket(ipAddress, port);
                BufferedReader streamRdr = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                PrintWriter streamWtr = new PrintWriter(
                        socket.getOutputStream(), true)
        ) {

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
