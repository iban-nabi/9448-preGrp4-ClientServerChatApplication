package chat_server;

import chat_server.ServerGUI.ServerGUI;

/**
 * Start the server for Chat Service
 */
public class StartServerGUI {
    public static void main(String[] args) {
        new ServerGUI();

    }
}
